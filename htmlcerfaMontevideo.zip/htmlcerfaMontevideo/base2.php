<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>fichedescriptiveformulaire_5184.pdf</title>
        <style type="text/css" media="print">.hide{display:none}</style>
    </head>
    <body style="margin:0;padding:0">
		
        <div style="margin:0px;z-index:-1"> 
			<img src="cerfaassoc.jpg" width="750"/>
			<div id="name" style="position:absolute;z-index:2;margin-top:142px;margin-left:30px">
				MATHE Guillaume
			</div>
			<div id="streetNumber" style="position:absolute;z-index:2;margin-top:185px;margin-left:40px">
				64
			</div>
			<div id="streetName" style="position:absolute;z-index:2;margin-top:185px;margin-left:120px">
				orfila
			</div>
			<div id="ZipCode" style="position:absolute;z-index:2;margin-top:205px;margin-left:104px">
				75020
			</div>
			<div id="City" style="position:absolute;z-index:2;margin-top:205px;margin-left:234px">
				PARIS
			</div>
			<div id="object" style="position:absolute;z-index:2;margin-top:247px;margin-left:24px;width:650px;line-height:16px">
				Elementum ac urna? Porttitor? Proin tincidunt et dapibus pid habitasse ac porttitor facilisis dignissim, nunc ac pulvinar nisi quis aliquet porttitor, hac eros lectus, vut tincidunt dignissim enim mus nisi, sed mauris scelerisque, porta, nec etiam, ultricies non mattis nunc ut pulvinar? Proin eros nec porta.
			</div>
			<img src="cerfaassoc-2.jpg" width="750"/>
			<div id="GiverName" style="position:absolute;z-index:2;margin-top:50px;margin-left:30px">
				MATHE
			</div>
			<div id="GiverFirstName" style="position:absolute;z-index:2;margin-top:50px;margin-left:375px">
				Guillaume
			</div>
			<div id="streetNumber" style="position:absolute;z-index:2;margin-top:103px;margin-left:30px">
				64 rue orfila
			</div>
			<div id="ZipCode" style="position:absolute;z-index:2;margin-top:125px;margin-left:100px">
				75020
			</div>
			<div id="City" style="position:absolute;z-index:2;margin-top:125px;margin-left:274px">
				PARIS
			</div>
		</div>
		
	</body>
</html>