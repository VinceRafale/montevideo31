<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <style type="text/css" media="print">.hide{display:none}</style>
    </head>
    <body style="margin:20px;padding:0">
        <div style="margin:1ex;height:2500px"> 
 
 
 
 
 
 
 
 
<div bgcolor="#ffffff" vlink="blue" link="blue"> 
<font size="3" face="Times"><span style="font-size:13px;font-family:Times"> 
<div style="top:53;margin-left:31"><b>N&deg; 11580*03</b></div> 
</span></font> 
<font size="4" face="Times"><span style="font-size:22px;font-family:Times"> 
<div style="top:18;margin-left:295"><b>Re&ccedil;u au titre des dons</b></div> 
<div style="top:46;margin-left:209"><b>&agrave; certains organismes d'int&eacute;r&ecirc;t g&eacute;n&eacute;ral</b></div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:14px;font-family:Times"> 
<div style="top:73;margin-left:169">Articles 200, 238 bis et 885-0 V bis A du code g&eacute;n&eacute;ral des imp&ocirc;ts (CGI)</div> 
</span></font> 

<table style="width:100%font-size:14px;font-family:Times;top:100px;border:1px solid black">
    <thead>
        <tr>
            <th style="width:100%;height:30px;background-color:gray;font-size:16px;text-align:center">
                B&eacute;n&eacute;ficiaire des versements
            </th>
        </tr>    
    </thead>
    <tr>
            <td style="width:100%">
                Nom ou d&eacute;nomination :
            </td>
    </tr>
    <tr>
            <td style="width:100%">
                .......................................................................................................................................................................................................
            </td>
    </tr>
    <tr>
            <td style="width:100%">
                Adresse :
            </td>
    </tr>
    <tr>
            <td style="width:100%">
                No............Rue.......................................................................................................................................................................................................
                Code postal............Commune.........................................................................................................................................................................
            </td>
    </tr>
    <tr>
            <td style="width:100%">
                Objet : 
            </td>
    </tr>
    <tr>
            <td style="width:100%">
                .......................................................................................................................................................................................................
                .......................................................................................................................................................................................................
                .......................................................................................................................................................................................................
            </td>
    </tr>
    
    <tr>
            <td style="width:100%">
                <hr />
            </td>
            </tr>
            <tr>
                <table>
                    <tr style="width:100%">
                        <td>
                            <b>Cochez la case concern&eacute;e (1) :</b>
                        </td>
                    </tr>
                    <tr style="width:100%">
                        <td width="width:10%">
                            <div style="border:1px black solid;width:10px;height:10px;float:left"></div>
                        </td>
                        <td width="width:90%">
                            <div style="float:left">Mus&eacute;e de France</div>
                        </td>
                    </tr>
            </table>
                
            </tr>
        </table>
        
<font size="3" face="Times"><span style="font-size:14px;font-family:Times"> 
<div style="position:absolute;top:358;left:31"></div> 

<div style="position:absolute;top:389;left:54">Association ou fondation reconnue d&#39;utilit&eacute; publique par d&eacute;cret en date du ........./ ..... /........... publi&eacute;  au  Journal</div> 

<div style="position:absolute;top:408;left:52">officiel du  ......./....../ .......... .  ou  association  situ&eacute;e  dans  le  d&eacute;partement  de  la  Moselle,  du  Bas-Rhin  ou</div> 
<div style="position:absolute;top:427;left:52">du Haut-Rhin dont la mission a &eacute;t&eacute; reconnue d&#39;utilit&eacute; publique par arr&ecirc;t&eacute; pr&eacute;fectoral en date du …./.…/……..</div> 
<div style="position:absolute;top:458;left:35;border:1px black solid;width:10px;height:10px;"></div>
<div style="position:absolute;top:458;left:54">Fondation  universitaire  ou  fondation  partenariale mentionn&eacute;es  respectivement  aux  articles  L.  719-12  et</div> 
<div style="position:absolute;top:477;left:52">L. 719-13 du code de l&#39;&eacute;ducation</div> 
<div style="position:absolute;top:508;left:35;border:1px black solid;width:10px;height:10px;"></div>
<div style="position:absolute;top:508;left:54">Fondation d&#39;entreprise</div> 
<div style="position:absolute;top:539;left:35;border:1px black solid;width:10px;height:10px;"></div>
<div style="position:absolute;top:539;left:56">Oeuvre ou organisme d&#39;int&eacute;r&ecirc;t g&eacute;n&eacute;ral</div> 
<div style="position:absolute;top:570;left:35;border:1px black solid;width:10px;height:10px;"></div>
<div style="position:absolute;top:570;left:54">Mus&eacute;e de France </div> 
<div style="position:absolute;top:601;left:35;border:1px black solid;width:10px;height:10px;"></div>
<div style="position:absolute;top:601;left:54">&eacute;tablissement d&#39;enseignement sup&eacute;rieur ou d’enseignement artistique public ou priv&eacute;, d’int&eacute;r&ecirc;t g&eacute;n&eacute;ral, &agrave; but</div> 
<div style="position:absolute;top:620;left:52">non lucratif</div> 
<div style="position:absolute;top:651;left:54">Organisme ayant pour objet exclusif de participer financi&egrave;rement &agrave; la cr&eacute;ation d&#39;entreprises</div> 
<div style="position:absolute;top:682;left:54">Association cultuelle ou de bienfaisance et &eacute;tablissement public des cultes reconnus d&#39;Alsace-Moselle</div> 
<div style="position:absolute;top:713;left:54">Organisme ayant pour activit&eacute; principale l&#39;organisation de festivals</div> 
<div style="position:absolute;top:744;left:54">Association fournissant gratuitement une aide alimentaire ou des soins m&eacute;dicaux &agrave; des personnes en difficult&eacute; ou</div> 
<div style="position:absolute;top:763;left:52">favorisant leur logement</div> 
<div style="position:absolute;top:794;left:56">Fondation du patrimoine ou fondation ou association qui affecte irr&eacute;vocablement les dons &agrave; la Fondation du</div> 
<div style="position:absolute;top:813;left:52">patrimoine, en vue de subventionner les  travaux  pr&eacute;vus par les conventions conclues entre la Fondation du</div> 
<div style="position:absolute;top:832;left:52">patrimoine et les propri&eacute;taires des immeubles (article L. 143-2-1 du code du patrimoine)</div> 
<div style="position:absolute;top:863;left:54">&eacute;tablissement de recherche public ou priv&eacute;, d’int&eacute;r&ecirc;t g&eacute;n&eacute;ral, &agrave; but non lucratif</div> 
<div style="position:absolute;top:894;left:54">Entreprise d’insertion ou entreprise de travail temporaire d’insertion (articles L. 5132-5 et L. 5132-6 du code du</div> 
<div style="position:absolute;top:913;left:52">travail).</div> 
<div style="position:absolute;top:944;left:54">Associations interm&eacute;diaires (article L. 5132-7 du code du travail)</div> 
<div style="position:absolute;top:975;left:54">Ateliers et chantiers d’insertion (article L. 5132-15 du code du travail)</div> 
<div style="position:absolute;top:1006;left:54">Entreprises adapt&eacute;es (article L. 5213-13 du code du travail)</div> 
<div style="position:absolute;top:1037;left:54">Agence nationale de la recherche (ANR)</div> 
<div style="position:absolute;top:1068;left:54">Soci&eacute;t&eacute; ou organisme agr&eacute;&eacute; de recherche scientifique ou technique (2)</div> 
<div style="position:absolute;top:1099;left:54">Autre organisme : ………………………………………………………………………………………………</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:11px;font-family:Times"> 
<div style="top:1139;left:31">(1) ou n&#39;indiquez que les renseignements concernant l&#39;organisme</div> 
<div style="position:absolute;top:1158;left:31">(2) dons effectu&eacute;s par les entreprises</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:13px;font-family:Times"> 
<div style="position:absolute;top:21;left:640">Num&eacute;ro d&#39;ordre du re&ccedil;u</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:11px;font-family:Times"> 
<div style="position:absolute;top:74;left:42">DGFIP</div> 
</span></font> 
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><font size="3" face="Times"><span style="font-size:18px;font-family:Times"> 
<div style="position:absolute;top:1287;left:373"><b>Donateur</b></div> 
</span></font> 

<font size="3" face="Times"><span style="font-size:14px;font-family:Times"> 
<div style="position:absolute;top:1318;left:31"><b>Nom :</b></div> 
<div style="position:absolute;top:1318;left:413"><b>Pr&eacute;noms :</b></div> 
<div style="position:absolute;top:1337;left:33">......................................................................................</div> 
<div style="position:absolute;top:1337;left:414">.........................................................................................</div> 
<div style="position:absolute;top:1375;left:31"><b>Adresse :</b></div> 
<div style="position:absolute;top:1394;left:33">.....................................................................................................................................................................................</div> 
<div style="position:inherit;float:left;top:1418;left:31"><b>Code postal </b>................... <b>Commune </b>.......................................................................................................................</div> 
<div style="position:absolute;top:1493;left:31">Le b&eacute;n&eacute;ficiaire reconnaît avoir re&ccedil;u au titre des dons et versements ouvrant droit &agrave; r&eacute;duction d&#39;impôt, la somme de : </div> 
<div style="position:absolute;top:1569;left:31">Somme en toutes lettres : ............................................................................................................................................</div> 
<div style="position:absolute;top:1607;left:31"><b>Date du versement ou du don : </b>......../ ................/ ...................... .</div> 
<div style="position:absolute;top:1645;left:31">Le b&eacute;n&eacute;ficiaire certifie sur l’honneur que les dons et versements qu’il re&ccedil;oit ouvrent droit &agrave; la r&eacute;duction d&#39;impôt</div> 
<div style="position:absolute;top:1664;left:31">pr&eacute;vue &agrave; l’article (3) :</div> 
<div style="position:absolute;top:1664;left:218">200 du CGI </div> 
<div style="position:absolute;top:1664;left:426">238 bis du CGI</div> 
<div style="position:absolute;top:1664;left:639">885-0 V bis A du CGI</div> 
<div style="position:absolute;top:1683;left:33">__________________________________________________________________________________________</div> 
<div style="position:absolute;top:1702;left:31"><b>Forme du don :</b></div> 
<div style="position:absolute;top:1740;left:54">Acte authentique</div> 
<div style="position:absolute;top:1740;left:235">Acte sous seing priv&eacute;</div> 
<div style="position:absolute;top:1740;left:479">D&eacute;claration de don manuel</div> 
<div style="position:absolute;top:1740;left:734">Autres</div> 
<div style="position:absolute;top:1978;left:33">__________________________________________________________________________________________</div> 
<div style="position:absolute;top:1797;left:31"><b>Nature du don :</b></div> 
<div style="position:absolute;top:1835;left:54">Num&eacute;raire</div> 
<div style="position:absolute;top:1835;left:235">Titres de soci&eacute;t&eacute;s cot&eacute;s</div> 
<div style="position:absolute;top:1835;left:479">Autres (4)</div> 
<div style="position:absolute;top:1872;left:33"><b>__________________________________________________________________________________________</b></div> 
<div style="position:absolute;top:1891;left:31"><b>En cas de don en num&eacute;raire, mode de versement du don :</b></div> 
<div style="position:absolute;top:1929;left:54">Remise d’esp&egrave;ces</div> 
<div style="position:absolute;top:1929;left:235">Ch&egrave;que</div> 
<div style="position:absolute;top:1929;left:479">Virement, pr&eacute;l&egrave;vement, carte bancaire</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:11px;font-family:Times"> 
<div style="position:absolute;top:1985;left:31">(3) L’organisme b&eacute;n&eacute;ficiaire peut cocher une ou plusieurs cases.</div> 
<div style="position:absolute;top:2006;left:58">L’organisme b&eacute;n&eacute;ficiaire peut, en application de l’article L. 80 C du livre des proc&eacute;dures fiscales, demander &agrave; l’administration s’il rel&egrave;ve</div> 
<div style="position:absolute;top:2025;left:58">de l’une des cat&eacute;gories d’organismes mentionn&eacute;es aux articles 200 et 238 bis du code g&eacute;n&eacute;ral des impôts.</div> 
<div style="position:absolute;top:2047;left:58">Il est rappel&eacute; que la d&eacute;livrance irr&eacute;guli&egrave;re de re&ccedil;us fiscaux par l’organisme b&eacute;n&eacute;ficiaire est susceptible de donner lieu, en application des</div> 
<div style="position:absolute;top:2062;left:58">dispositions de l&#39;article 1740 A du code g&eacute;n&eacute;ral des impôts, &agrave; une amende fiscale &eacute;gale &agrave; 25 % des sommes indûment mentionn&eacute;es sur</div> 
<div style="position:absolute;top:2078;left:58">ces documents.</div> 
<div style="position:absolute;top:2099;left:31">(4) notamment : abandon de revenus ou de produits ; frais engag&eacute;s par les b&eacute;n&eacute;voles, dont ils renoncent express&eacute;ment au remboursement</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:14px;font-family:Times"> 
<div style="position:absolute;top:2203;left:584">Date et signature</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:13px;font-family:Times"> 
<div style="position:absolute;top:2275;left:559">......./......./ ............</div> 
</span></font> 
<font size="3" face="Times"><span style="font-size:14px;font-family:Times"> 
<div style="position:absolute;top:1526;left:466"><b>euros</b></div> 
</span></font> 
</div> 
<div style="height:30px;width:30px;background-color:green;margin-top:1500"></div>
 
</div></body></html>